<?php return array (
  'category-list' => 'App\\Http\\Livewire\\CategoryList',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'menu' => 'App\\Http\\Livewire\\Menu',
  'product' => 'App\\Http\\Livewire\\Product',
  'product-list' => 'App\\Http\\Livewire\\ProductList',
);