<div>
    <div class="grid md:grid-cols-3 gap-4">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-75 h-75 md:w-85 md:h-auto md:rounded-none rounded-full mx-auto">
            <img src="<?php echo e(asset('storage/img/'.$category['img'])); ?>" />
        <p class="text-gray-800 md:font-sans text-3xl text-center gap-8"><?php echo e($category['name']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH E:\Projeler\lukspastacafe\resources\views/livewire/category-list.blade.php ENDPATH**/ ?>