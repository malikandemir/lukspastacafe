<div>
    <span>{{$count}}</span>
    <x-jet-button wire:click="decrement">-</x-jet-button>
    <x-jet-button wire:click="increment">+</x-jet-button>
</div>
